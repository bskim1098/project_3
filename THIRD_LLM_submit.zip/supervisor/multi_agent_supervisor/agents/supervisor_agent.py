# TODO: 협업 통합 단계에서 구현 예정
# 역할: first_agent와 third_agent 실행 순서, 실패 분기, 결과 전달 총괄
# 주의: ce_ 또는 vc_ 판단 내용을 직접 생성하지 않고 라우팅만 담당
