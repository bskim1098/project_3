# TODO: 협업 통합 단계에서 구현 예정
# 역할: ce_ 결과를 third_agent에 전달하고 vc_ 최종 검토 결과를 수집
